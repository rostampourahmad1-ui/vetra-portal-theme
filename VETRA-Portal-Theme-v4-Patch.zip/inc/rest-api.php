<?php
/**
 * Vetra Projects REST API.
 *
 * Namespace: vetra/v1
 * Stable record IDs are returned as id. All write operations require
 * authenticated WordPress capabilities; public reads are configurable.
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }

function vetra_rest_project_schema() {
	$schema = array();
	foreach ( vetra_project_fields() as $key => $field ) {
		$schema[ $key ] = array( 'description' => $field['label'], 'type' => in_array( $field['type'], array( 'integer' ), true ) ? 'integer' : 'string' );
	}
	return $schema;
}
function vetra_rest_project_can_read() {
	return is_user_logged_in() || vetra_option( 'projects_public', true );
}
function vetra_rest_project_can_create() { return current_user_can( 'vetra_create_projects' ) || current_user_can( 'vetra_submit_projects' ); }
function vetra_rest_project_can_edit( WP_REST_Request $request ) {
	$project = vetra_project_get( absint( $request['id'] ) );
	return $project && vetra_project_can_edit( $project );
}
function vetra_rest_project_can_delete( WP_REST_Request $request ) {
	$project = vetra_project_get( absint( $request['id'] ) );
	return $project && vetra_project_can_delete( $project );
}
function vetra_rest_project_prepare( $project ) {
	$data = array( 'id' => (int) $project->id );
	foreach ( vetra_project_fields() as $key => $field ) {
		if ( isset( $project->{$key} ) ) { $data[ $key ] = 'integer' === $field['type'] ? (int) $project->{$key } : $project->{$key}; }
	}
	$data['featured_image_url'] = $project->featured_image_id ? wp_get_attachment_image_url( $project->featured_image_id, 'full' ) : '';
	return $data;
}
function vetra_rest_register_routes() {
	register_rest_route( 'vetra/v1', '/projects', array(
		array(
			'methods' => WP_REST_Server::READABLE,
			'permission_callback' => 'vetra_rest_project_can_read',
			'callback' => function( WP_REST_Request $r ) {
				$items = vetra_project_query( array( 'number' => min( 100, max( 1, absint( $r->get_param( 'per_page' ) ?: 50 ) ) ), 'offset' => absint( $r->get_param( 'offset' ) ) ) );
				return rest_ensure_response( array_map( 'vetra_rest_project_prepare', $items ) );
			},
			'args' => array( 'per_page' => array( 'sanitize_callback' => 'absint' ), 'offset' => array( 'sanitize_callback' => 'absint' ) ),
		),
		array(
			'methods' => WP_REST_Server::CREATABLE,
			'permission_callback' => 'vetra_rest_project_can_create',
			'callback' => function( WP_REST_Request $r ) {
				$data = vetra_project_sanitize_data( $r->get_json_params() );
				if ( empty( $data['project_name'] ) ) { return new WP_Error( 'missing_project_name', 'نام پروژه الزامی است.', array( 'status' => 400 ) ); }
				$data['created_by'] = get_current_user_id();
				$id = vetra_project_upsert( $data );
				return $id ? new WP_REST_Response( vetra_rest_project_prepare( vetra_project_get( $id ) ), 201 ) : new WP_Error( 'save_failed', 'ذخیره پروژه انجام نشد.', array( 'status' => 500 ) );
			},
			'schema' => array( '$schema' => 'http://json-schema.org/draft-04/schema#', 'title' => 'Vetra Project', 'type' => 'object', 'properties' => vetra_rest_project_schema() ),
		),
	) );
	register_rest_route( 'vetra/v1', '/projects/(?P<id>\d+)', array(
		array(
			'methods' => WP_REST_Server::READABLE,
			'permission_callback' => 'vetra_rest_project_can_read',
			'callback' => function( WP_REST_Request $r ) { $p = vetra_project_get( absint( $r['id'] ) ); return $p ? rest_ensure_response( vetra_rest_project_prepare( $p ) ) : new WP_Error( 'not_found', 'پروژه پیدا نشد.', array( 'status' => 404 ) ); },
		),
		array(
			'methods' => WP_REST_Server::EDITABLE,
			'permission_callback' => 'vetra_rest_project_can_edit',
			'callback' => function( WP_REST_Request $r ) {
				$id = absint( $r['id'] ); $p = vetra_project_get( $id ); $data = vetra_project_sanitize_data( $r->get_json_params() ); $saved = vetra_project_upsert( $data, $id );
				return $saved ? rest_ensure_response( vetra_rest_project_prepare( vetra_project_get( $id ) ) ) : new WP_Error( 'save_failed', 'ویرایش پروژه انجام نشد.', array( 'status' => 500 ) );
			},
		),
		array(
			'methods' => WP_REST_Server::DELETABLE,
			'permission_callback' => 'vetra_rest_project_can_delete',
			'callback' => function( WP_REST_Request $r ) {
				global $wpdb; $id = absint( $r['id'] ); $wpdb->delete( vetra_projects_table(), array( 'id' => $id ), array( '%d' ) ); return new WP_REST_Response( array( 'deleted' => true, 'id' => $id ), 200 );
			},
		),
	) );
}
add_action( 'rest_api_init', 'vetra_rest_register_routes' );

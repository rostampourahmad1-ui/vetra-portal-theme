<?php
/**
 * Vetra independent project data store.
 *
 * Public API: vetra_project_get(), vetra_project_query(), vetra_project_upsert(),
 * vetra_project_can_edit(), vetra_project_fields().
 *
 * @package VetraPortal
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }

function vetra_projects_table() {
	global $wpdb;
	return $wpdb->prefix . 'vetra_projects';
}

function vetra_project_schema_version() { return '2.0.0'; }

function vetra_project_install_schema() {
	global $wpdb;
	$table = vetra_projects_table();
	$exists = $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $table ) );
	if ( $exists === $table && version_compare( (string) get_option( 'vetra_projects_schema_version', '0.0.0' ), vetra_project_schema_version(), '>=' ) ) { return; }
	require_once ABSPATH . 'wp-admin/includes/upgrade.php';
	$charset = $wpdb->get_charset_collate();
	/*
	 * The legacy status column is intentionally retained for non-destructive upgrades,
	 * but it is deprecated and never read/written by the application. The public
	 * data model contains no approval-status field.
	 */
	$sql = "CREATE TABLE {$table} (
		id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
		project_name varchar(255) NOT NULL,
		client_name varchar(255) NOT NULL DEFAULT '',
		project_usage varchar(190) NOT NULL DEFAULT '',
		contract_type varchar(190) NOT NULL DEFAULT '',
		contract_number varchar(190) NOT NULL DEFAULT '',
		contractor varchar(255) NOT NULL DEFAULT '',
		contract_start varchar(80) NOT NULL DEFAULT '',
		contract_duration varchar(100) NOT NULL DEFAULT '',
		initial_amount varchar(120) NOT NULL DEFAULT '',
		project_supervisor varchar(255) NOT NULL DEFAULT '',
		project_manager varchar(255) NOT NULL DEFAULT '',
		site_supervisor varchar(255) NOT NULL DEFAULT '',
		project_address text NOT NULL,
		client_address text NOT NULL,
		urban_file_number varchar(190) NOT NULL DEFAULT '',
		registry_sub varchar(100) NOT NULL DEFAULT '',
		registry_main varchar(100) NOT NULL DEFAULT '',
		status varchar(20) NOT NULL DEFAULT '',
		featured_image_id bigint(20) unsigned NOT NULL DEFAULT 0,
		category varchar(190) NOT NULL DEFAULT '',
		summary text NOT NULL,
		description longtext NOT NULL,
		created_by bigint(20) unsigned NOT NULL DEFAULT 0,
		created_at datetime NOT NULL,
		updated_at datetime NOT NULL,
		PRIMARY KEY (id),
		KEY created_by (created_by),
		KEY contract_number (contract_number)
	) {$charset};";
	dbDelta( $sql );
	update_option( 'vetra_projects_schema_version', vetra_project_schema_version(), false );
}
add_action( 'after_setup_theme', 'vetra_project_install_schema', 20 );
add_action( 'after_switch_theme', 'vetra_project_install_schema', 20 );

function vetra_project_fields() {
	return array(
		'project_name'       => array( 'label' => 'نام پروژه', 'type' => 'text', 'required' => true ),
		'client_name'        => array( 'label' => 'نام کارفرما', 'type' => 'text' ),
		'project_usage'      => array( 'label' => 'کاربری', 'type' => 'text' ),
		'contract_type'      => array( 'label' => 'نوع قرارداد', 'type' => 'text' ),
		'contract_number'    => array( 'label' => 'شماره قرارداد', 'type' => 'text' ),
		'contractor'         => array( 'label' => 'پیمانکار', 'type' => 'text' ),
		'contract_start'     => array( 'label' => 'تاریخ شروع قرارداد', 'type' => 'text' ),
		'contract_duration'  => array( 'label' => 'مدت قرارداد', 'type' => 'text' ),
		'initial_amount'     => array( 'label' => 'مبلغ اولیه پیمان', 'type' => 'text' ),
		'project_supervisor' => array( 'label' => 'ناظر پروژه', 'type' => 'text' ),
		'project_manager'    => array( 'label' => 'مدیر پروژه', 'type' => 'text' ),
		'site_supervisor'    => array( 'label' => 'سرپرست کارگاه', 'type' => 'text' ),
		'project_address'    => array( 'label' => 'آدرس پروژه', 'type' => 'textarea' ),
		'client_address'     => array( 'label' => 'آدرس کارفرما', 'type' => 'textarea' ),
		'urban_file_number'  => array( 'label' => 'شماره پرونده شهرسازی', 'type' => 'text' ),
		'registry_sub'       => array( 'label' => 'پلاک ثبتی فرعی', 'type' => 'text' ),
		'registry_main'      => array( 'label' => 'پلاک ثبتی اصلی', 'type' => 'text' ),
		'category'           => array( 'label' => 'دسته پروژه', 'type' => 'text' ),
		'summary'            => array( 'label' => 'خلاصه پروژه', 'type' => 'textarea' ),
		'description'        => array( 'label' => 'توضیحات کامل', 'type' => 'textarea' ),
		'featured_image_id'  => array( 'label' => 'شناسه تصویر شاخص', 'type' => 'integer' ),
		'created_by'         => array( 'label' => 'شناسه ایجادکننده', 'type' => 'integer' ),
		'created_at'         => array( 'label' => 'زمان ایجاد', 'type' => 'datetime' ),
		'updated_at'         => array( 'label' => 'زمان آخرین ویرایش', 'type' => 'datetime' ),
	);
}

function vetra_project_field_ids() {
	return array_keys( vetra_project_fields() );
}

function vetra_project_extra_fields() { return array(); } // Compatibility alias.

function vetra_project_get( $id ) {
	global $wpdb;
	return $wpdb->get_row( $wpdb->prepare( 'SELECT * FROM ' . vetra_projects_table() . ' WHERE id = %d', absint( $id ) ) );
}

function vetra_project_query( $args = array() ) {
	global $wpdb;
	$args = wp_parse_args( $args, array( 'number' => 50, 'offset' => 0, 'created_by' => 0 ) );
	$where = array( '1=1' );
	$values = array();
	if ( $args['created_by'] ) { $where[] = 'created_by = %d'; $values[] = absint( $args['created_by'] ); }
	$values[] = max( 1, min( 500, absint( $args['number'] ) ) );
	$values[] = absint( $args['offset'] );
	$sql = 'SELECT * FROM ' . vetra_projects_table() . ' WHERE ' . implode( ' AND ', $where ) . ' ORDER BY updated_at DESC LIMIT %d OFFSET %d';
	return $wpdb->get_results( $wpdb->prepare( $sql, $values ) );
}

function vetra_project_sanitize_data( $source ) {
	$data = array();
	foreach ( vetra_project_fields() as $key => $field ) {
		if ( in_array( $key, array( 'featured_image_id', 'created_by', 'created_at', 'updated_at' ), true ) ) { continue; }
		$value = wp_unslash( $source[ $key ] ?? '' );
		$data[ $key ] = 'description' === $key ? wp_kses_post( $value ) : ( 'textarea' === $field['type'] ? sanitize_textarea_field( $value ) : sanitize_text_field( $value ) );
	}
	$data['project_name'] = sanitize_text_field( wp_unslash( $source['project_name'] ?? '' ) );
	return $data;
}

function vetra_project_upload_image( $file ) {
	if ( empty( $file['name'] ) || ! current_user_can( 'upload_files' ) ) { return 0; }
	require_once ABSPATH . 'wp-admin/includes/file.php';
	require_once ABSPATH . 'wp-admin/includes/image.php';
	$uploaded = wp_handle_upload( $file, array( 'test_form' => false, 'mimes' => array( 'jpg|jpeg|jpe' => 'image/jpeg', 'png' => 'image/png', 'webp' => 'image/webp' ) ) );
	if ( isset( $uploaded['error'] ) ) { return 0; }
	$attachment_id = wp_insert_attachment(
		array( 'post_mime_type' => $uploaded['type'], 'post_title' => sanitize_file_name( wp_basename( $uploaded['file'] ) ), 'post_status' => 'inherit' ),
		$uploaded['file']
	);
	if ( is_wp_error( $attachment_id ) ) { return 0; }
	wp_update_attachment_metadata( $attachment_id, wp_generate_attachment_metadata( $attachment_id, $uploaded['file'] ) );
	return absint( $attachment_id );
}

function vetra_project_upsert( $data, $id = 0 ) {
	global $wpdb;
	$table = vetra_projects_table();
	$allowed = array_diff( array_keys( vetra_project_fields() ), array( 'project_name', 'featured_image_id', 'created_by', 'created_at', 'updated_at' ) );
	$record = array( 'project_name' => sanitize_text_field( $data['project_name'] ?? '' ) );
	foreach ( $allowed as $key ) { if ( array_key_exists( $key, $data ) ) { $record[ $key ] = $data[ $key ]; } }
	if ( array_key_exists( 'featured_image_id', $data ) ) { $record['featured_image_id'] = absint( $data['featured_image_id'] ); }
	$now = current_time( 'mysql' );
	$record['updated_at'] = $now;
	if ( $id ) {
		$result = $wpdb->update( $table, $record, array( 'id' => absint( $id ) ), vetra_project_formats( $record ), array( '%d' ) );
		return false === $result ? 0 : absint( $id );
	}
	$record['created_by'] = absint( $data['created_by'] ?? get_current_user_id() );
	$record['created_at'] = $now;
	$result = $wpdb->insert( $table, $record, vetra_project_formats( $record ) );
	return $result ? absint( $wpdb->insert_id ) : 0;
}

function vetra_project_formats( $record ) {
	$integer_fields = array( 'featured_image_id', 'created_by' );
	$formats = array();
	foreach ( $record as $key => $value ) { $formats[] = in_array( $key, $integer_fields, true ) ? '%d' : '%s'; }
	return $formats;
}

function vetra_project_can_create() { return is_user_logged_in() && ( current_user_can( 'vetra_create_projects' ) || current_user_can( 'vetra_submit_projects' ) ); }
function vetra_project_can_edit( $project ) {
	return $project && is_user_logged_in() && ( current_user_can( 'vetra_edit_all_projects' ) || ( current_user_can( 'vetra_edit_own_projects' ) && get_current_user_id() === (int) $project->created_by ) );
}
function vetra_project_can_delete( $project ) {
	return $project && is_user_logged_in() && ( current_user_can( 'vetra_delete_projects' ) || current_user_can( 'manage_options' ) );
}

function vetra_project_roles() {
	$editor_caps = array( 'read' => true, 'upload_files' => true, 'vetra_create_projects' => true, 'vetra_submit_projects' => true, 'vetra_edit_own_projects' => true );
	$manager_caps = array_merge( $editor_caps, array( 'vetra_manage_projects' => true, 'vetra_edit_all_projects' => true, 'vetra_delete_projects' => true ) );
	foreach ( array( array( 'vetra_project_editor', 'ویرایشگر پروژه وترا', $editor_caps ), array( 'vetra_project_manager', 'مدیر پروژه وترا', $manager_caps ) ) as $role_def ) {
		$role = get_role( $role_def[0] );
		if ( ! $role ) { $role = add_role( $role_def[0], $role_def[1], $role_def[2] ); }
		if ( $role ) { foreach ( array_keys( $role_def[2] ) as $cap ) { $role->add_cap( $cap ); } }
	}
	$admin = get_role( 'administrator' );
	if ( $admin ) { foreach ( array_keys( $manager_caps ) as $cap ) { $admin->add_cap( $cap ); } }
}
add_action( 'after_setup_theme', 'vetra_project_roles', 25 );

function vetra_project_render_field( $key, $field, $get ) {
	$required = ! empty( $field['required'] ) ? ' required' : '';
	?>
	<p><label for="vetra-<?php echo esc_attr( $key ); ?>"><?php echo esc_html( $field['label'] ); ?><?php if ( $required ) : ?> <span aria-hidden="true">*</span><?php endif; ?></label>
	<?php if ( 'textarea' === $field['type'] || 'description' === $key ) : ?>
		<textarea id="vetra-<?php echo esc_attr( $key ); ?>" name="<?php echo esc_attr( $key ); ?>" rows="4"<?php echo $required; ?>><?php echo esc_textarea( $get( $key ) ); ?></textarea>
	<?php else : ?>
		<input id="vetra-<?php echo esc_attr( $key ); ?>" type="text" name="<?php echo esc_attr( $key ); ?>" value="<?php echo esc_attr( $get( $key ) ); ?>"<?php echo $required; ?>>
	<?php endif; ?></p>
	<?php
}

function vetra_project_render_fields( $project = null, $admin = false ) {
	$get = function( $key ) use ( $project ) { return $project ? ( $project->{$key} ?? '' ) : ''; };
	$groups = array(
		'identity' => array( 'عنوان' => '۱. مشخصات پایه', 'fields' => array( 'project_name', 'client_name', 'project_usage', 'category' ) ),
		'contract' => array( 'عنوان' => '۲. قرارداد', 'fields' => array( 'contract_type', 'contract_number', 'contractor', 'contract_start', 'contract_duration', 'initial_amount' ) ),
		'team' => array( 'عنوان' => '۳. عوامل پروژه', 'fields' => array( 'project_supervisor', 'project_manager', 'site_supervisor' ) ),
		'address' => array( 'عنوان' => '۴. نشانی و ثبتی', 'fields' => array( 'project_address', 'client_address', 'urban_file_number', 'registry_sub', 'registry_main' ) ),
		'extra' => array( 'عنوان' => '۵. محتوای تکمیلی', 'fields' => array( 'summary', 'description' ) ),
	);
	?>
	<?php foreach ( $groups as $group ) : ?>
	<section class="vetra-project-form__group"><h3><?php echo esc_html( $group['عنوان'] ); ?></h3><div class="vetra-project-form__grid">
		<?php foreach ( $group['fields'] as $key ) : vetra_project_render_field( $key, vetra_project_fields()[ $key ], $get ); endforeach; ?>
	</div></section>
	<?php endforeach; ?>
	<section class="vetra-project-form__group"><h3>۶. رسانه</h3><p><label for="vetra-featured-image">تصویر شاخص پروژه</label><input id="vetra-featured-image" type="file" name="featured_image" accept="image/jpeg,image/png,image/webp"></p></section>
	<?php
}

function vetra_project_admin_menu() {
	add_menu_page( 'پروژه‌ها', 'پروژه‌ها', 'vetra_manage_projects', 'vetra-projects', 'vetra_project_admin_page', 'dashicons-building', 25 );
	add_submenu_page( 'vetra-projects', 'افزودن پروژه', 'افزودن پروژه', 'vetra_manage_projects', 'vetra-projects-add', 'vetra_project_admin_form_page' );
}
add_action( 'admin_menu', 'vetra_project_admin_menu' );

function vetra_project_admin_page() {
	if ( ! current_user_can( 'vetra_manage_projects' ) ) { return; }
	$projects = vetra_project_query( array( 'number' => 100 ) );
	?>
	<div class="wrap vetra-admin-wrap" dir="rtl"><h1>پروژه‌ها <a class="page-title-action" href="<?php echo esc_url( admin_url( 'admin.php?page=vetra-projects-add' ) ); ?>">افزودن پروژه</a></h1>
	<div class="vetra-admin-card"><p>مخزن مستقل پروژه‌ها؛ شناسه هر رکورد ثابت است و دسترسی برنامه‌ای فقط از توابع و API مجاز انجام می‌شود.</p></div>
	<table class="widefat striped"><thead><tr><th>شناسه</th><th>نام پروژه</th><th>کارفرما</th><th>کاربری</th><th>آخرین ویرایش</th><th>عملیات</th></tr></thead><tbody>
	<?php if ( $projects ) : foreach ( $projects as $project ) : ?>
	<tr><td><?php echo esc_html( $project->id ); ?></td><td><strong><?php echo esc_html( $project->project_name ); ?></strong></td><td><?php echo esc_html( $project->client_name ); ?></td><td><?php echo esc_html( $project->project_usage ); ?></td><td><?php echo esc_html( $project->updated_at ); ?></td><td><a class="button" href="<?php echo esc_url( admin_url( 'admin.php?page=vetra-projects-add&project_id=' . $project->id ) ); ?>">ویرایش</a></td></tr>
	<?php endforeach; else : ?><tr><td colspan="6">هنوز پروژه‌ای ثبت نشده است.</td></tr><?php endif; ?></tbody></table></div>
	<?php
}

function vetra_project_admin_form_page() {
	if ( ! current_user_can( 'vetra_manage_projects' ) ) { return; }
	$project = vetra_project_get( absint( $_GET['project_id'] ?? 0 ) );
	?>
	<div class="wrap vetra-admin-wrap" dir="rtl"><h1><?php echo $project ? 'ویرایش پروژه' : 'افزودن پروژه'; ?></h1>
	<?php if ( isset( $_GET['saved'] ) ) : ?><div class="notice notice-success"><p>اطلاعات پروژه با موفقیت ذخیره شد.</p></div><?php endif; ?>
	<div class="vetra-admin-card"><form class="vetra-project-form" method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" enctype="multipart/form-data">
	<input type="hidden" name="action" value="vetra_save_project"><input type="hidden" name="project_id" value="<?php echo esc_attr( $project ? $project->id : 0 ); ?>"><?php wp_nonce_field( 'vetra_project_admin', 'vetra_project_admin_nonce' ); ?>
	<?php vetra_project_render_fields( $project, true ); ?><button class="button button-primary">ذخیره پروژه</button></form>
	<?php if ( $project && vetra_project_can_delete( $project ) ) : ?><form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" style="margin-top:12px"><input type="hidden" name="action" value="vetra_delete_project"><input type="hidden" name="project_id" value="<?php echo esc_attr( $project->id ); ?>"><?php wp_nonce_field( 'vetra_project_admin', 'vetra_project_admin_nonce' ); ?><button class="button" onclick="return confirm('حذف پروژه انجام شود؟');">حذف پروژه</button></form><?php endif; ?>
	</div></div>
	<?php
}

function vetra_project_admin_post_handlers() {
	$action = sanitize_key( wp_unslash( $_POST['action'] ?? '' ) );
	if ( 'vetra_save_project' === $action ) {
		if ( ! current_user_can( 'vetra_manage_projects' ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['vetra_project_admin_nonce'] ?? '' ) ), 'vetra_project_admin' ) ) { wp_die( 'دسترسی غیرمجاز.', 'وترا', array( 'response' => 403 ) ); }
		$id = absint( $_POST['project_id'] ?? 0 ); $existing = $id ? vetra_project_get( $id ) : null;
		if ( $existing && ! vetra_project_can_edit( $existing ) ) { wp_die( 'اجازه ویرایش این پروژه را ندارید.', 'وترا', array( 'response' => 403 ) ); }
		$data = vetra_project_sanitize_data( $_POST );
		if ( '' === $data['project_name'] ) { wp_die( 'نام پروژه الزامی است.', 'وترا', array( 'response' => 400 ) ); }
		$data['created_by'] = $existing ? (int) $existing->created_by : get_current_user_id();
		$image_id = vetra_project_upload_image( $_FILES['featured_image'] ?? array() );
		if ( $image_id ) { $data['featured_image_id'] = $image_id; }
		$saved = vetra_project_upsert( $data, $id );
		wp_safe_redirect( admin_url( 'admin.php?page=vetra-projects-add&project_id=' . absint( $saved ) . '&saved=1' ) ); exit;
	}
	if ( 'vetra_delete_project' === $action ) {
		if ( ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['vetra_project_admin_nonce'] ?? '' ) ), 'vetra_project_admin' ) ) { wp_die( 'درخواست نامعتبر است.', 'وترا', array( 'response' => 403 ) ); }
		$id = absint( $_POST['project_id'] ?? 0 ); $project = vetra_project_get( $id );
		if ( ! vetra_project_can_delete( $project ) ) { wp_die( 'اجازه حذف این پروژه را ندارید.', 'وترا', array( 'response' => 403 ) ); }
		global $wpdb; $wpdb->delete( vetra_projects_table(), array( 'id' => $id ), array( '%d' ) );
		wp_safe_redirect( admin_url( 'admin.php?page=vetra-projects&deleted=1' ) ); exit;
	}
}
add_action( 'admin_post_vetra_save_project', 'vetra_project_admin_post_handlers' );
add_action( 'admin_post_vetra_delete_project', 'vetra_project_admin_post_handlers' );

function vetra_project_frontend_process() {
	if ( empty( $_POST['vetra_project_submit'] ) ) { return; }
	if ( ! vetra_project_can_create() ) { wp_die( 'شما مجوز ثبت پروژه ندارید.', 'وترا', array( 'response' => 403 ) ); }
	if ( ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['vetra_project_nonce'] ?? '' ) ), 'vetra_project_frontend' ) ) { wp_die( 'درخواست نامعتبر است.', 'وترا', array( 'response' => 403 ) ); }
	$id = absint( $_POST['project_id'] ?? 0 ); $project = $id ? vetra_project_get( $id ) : null;
	if ( $project && ! vetra_project_can_edit( $project ) ) { wp_die( 'اجازه ویرایش این پروژه را ندارید.', 'وترا', array( 'response' => 403 ) ); }
	$data = vetra_project_sanitize_data( $_POST );
	if ( '' === $data['project_name'] ) { wp_die( 'نام پروژه الزامی است.', 'وترا', array( 'response' => 400 ) ); }
	$data['created_by'] = $project ? (int) $project->created_by : get_current_user_id();
	$image_id = vetra_project_upload_image( $_FILES['featured_image'] ?? array() );
	if ( $image_id ) { $data['featured_image_id'] = $image_id; }
	$saved = vetra_project_upsert( $data, $id );
	if ( $saved ) { wp_safe_redirect( add_query_arg( 'vetra_project_saved', $saved, wp_get_referer() ?: home_url( '/' ) ) ); exit; }
	wp_die( 'ذخیره پروژه انجام نشد.', 'وترا', array( 'response' => 500 ) );
}
add_action( 'template_redirect', 'vetra_project_frontend_process', 1 );

function vetra_project_form_shortcode( $atts ) {
	if ( ! is_user_logged_in() ) { return '<div class="vetra-content-card" role="alert">برای ثبت پروژه ابتدا وارد حساب کاربری شوید.</div>'; }
	if ( ! vetra_project_can_create() ) { return '<div class="vetra-content-card" role="alert">حساب شما مجوز ثبت پروژه ندارد.</div>'; }
	$atts = shortcode_atts( array( 'id' => 0 ), $atts, 'vetra_project_form' );
	$project = vetra_project_get( absint( $atts['id'] ) );
	if ( $project && ! vetra_project_can_edit( $project ) ) { return '<div class="vetra-content-card" role="alert">اجازه ویرایش این پروژه را ندارید.</div>'; }
	ob_start(); ?>
	<form class="vetra-project-form" method="post" enctype="multipart/form-data" novalidate>
	<?php wp_nonce_field( 'vetra_project_frontend', 'vetra_project_nonce' ); ?>
	<input type="hidden" name="vetra_project_submit" value="1"><input type="hidden" name="project_id" value="<?php echo esc_attr( $project ? $project->id : 0 ); ?>">
	<?php if ( isset( $_GET['vetra_project_saved'] ) ) : ?><p class="vetra-form-success" role="status">پروژه با موفقیت ذخیره شد.</p><?php endif; ?>
	<?php vetra_project_render_fields( $project ); ?><button class="vetra-button vetra-button--primary" type="submit"><?php echo $project ? 'ذخیره ویرایش پروژه' : 'ثبت پروژه'; ?></button>
	</form>
	<?php return ob_get_clean();
}
add_shortcode( 'vetra_project_form', 'vetra_project_form_shortcode' );

function vetra_project_list_shortcode( $atts ) {
	$atts = shortcode_atts( array( 'number' => 12 ), $atts, 'vetra_project_list' );
	$projects = vetra_project_query( array( 'number' => absint( $atts['number'] ) ) );
	ob_start();
	if ( $projects ) {
		echo '<div class="vetra-project-grid vetra-project-grid--shortcode">';
		foreach ( $projects as $project ) {
			$detail = add_query_arg( 'vetra_project_id', $project->id, get_permalink() );
			echo '<article class="vetra-project-card">';
			echo $project->featured_image_id ? wp_get_attachment_image( $project->featured_image_id, 'large' ) : '<img src="' . esc_url( VETRA_PORTAL_URI . '/assets/images/art-building.png' ) . '" alt="" loading="lazy">';
			echo '<div class="vetra-project-card__overlay"><span>' . esc_html( $project->project_usage ) . '</span><h3>' . esc_html( $project->project_name ) . '</h3><a href="' . esc_url( $detail ) . '">مشاهده پروژه</a></div></article>';
		}
		echo '</div>';
	} else { echo '<p class="vetra-content-card">هنوز پروژه‌ای برای نمایش ثبت نشده است.</p>'; }
	return ob_get_clean();
}
add_shortcode( 'vetra_project_list', 'vetra_project_list_shortcode' );

function vetra_project_detail_shortcode( $atts ) {
	$atts = shortcode_atts( array( 'id' => absint( $_GET['vetra_project_id'] ?? 0 ) ), $atts, 'vetra_project_detail' );
	$project = vetra_project_get( absint( $atts['id'] ) );
	if ( ! $project ) { return '<p class="vetra-content-card">اطلاعات پروژه در دسترس نیست.</p>'; }
	if ( ! vetra_project_can_edit( $project ) && ! vetra_project_can_create() && ! vetra_option( 'projects_public', true ) ) { return '<p class="vetra-content-card">دسترسی به این پروژه مجاز نیست.</p>'; }
	ob_start(); ?>
	<article class="vetra-project-single vetra-container"><header class="vetra-project-single__header"><span class="vetra-kicker"><i></i>اطلاعات پروژه</span><h1><?php echo esc_html( $project->project_name ); ?></h1><p><?php echo esc_html( $project->summary ); ?></p></header>
	<?php if ( $project->featured_image_id ) : ?><div class="vetra-project-single__image"><?php echo wp_get_attachment_image( $project->featured_image_id, 'full' ); ?></div><?php endif; ?>
	<div class="vetra-project-single__facts"><?php foreach ( vetra_project_fields() as $key => $field ) : $value = $project->{$key} ?? ''; if ( $value && ! in_array( $key, array( 'description', 'summary', 'featured_image_id', 'created_by', 'created_at', 'updated_at' ), true ) ) : ?><div><span><?php echo esc_html( $field['label'] ); ?></span><strong><?php echo nl2br( esc_html( $value ) ); ?></strong></div><?php endif; endforeach; ?></div>
	<div class="vetra-entry-content"><?php echo wpautop( wp_kses_post( $project->description ) ); ?></div></article>
	<?php return ob_get_clean();
}
add_shortcode( 'vetra_project_detail', 'vetra_project_detail_shortcode' );

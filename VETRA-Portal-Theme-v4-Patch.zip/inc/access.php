<?php
/**
 * Vetra access, role and front-end administration controls.
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }

function vetra_access_role_choices() {
	$roles = wp_roles()->roles;
	$out = array();
	foreach ( $roles as $slug => $role ) { $out[ $slug ] = translate_user_role( $role['name'] ); }
	return $out;
}
function vetra_access_selected_roles( $key, $fallback ) {
	$value = get_option( $key, $fallback );
	return array_values( array_filter( array_map( 'sanitize_key', (array) $value ) ) );
}
function vetra_access_sync_project_caps() {
	$create = vetra_access_selected_roles( 'vetra_project_create_roles', array( 'vetra_project_editor', 'vetra_project_manager' ) );
	$edit   = vetra_access_selected_roles( 'vetra_project_edit_roles', array( 'vetra_project_editor', 'vetra_project_manager' ) );
	$delete = vetra_access_selected_roles( 'vetra_project_delete_roles', array( 'vetra_project_manager' ) );
	$all = wp_roles()->roles;
	foreach ( $all as $slug => $unused ) {
		$role = get_role( $slug ); if ( ! $role ) { continue; }
		if ( in_array( $slug, $create, true ) ) { $role->add_cap( 'vetra_create_projects' ); $role->add_cap( 'vetra_submit_projects' ); } else { $role->remove_cap( 'vetra_create_projects' ); $role->remove_cap( 'vetra_submit_projects' ); }
		if ( in_array( $slug, $edit, true ) ) { $role->add_cap( 'vetra_edit_own_projects' ); } else { $role->remove_cap( 'vetra_edit_own_projects' ); }
		if ( in_array( $slug, $delete, true ) ) { $role->add_cap( 'vetra_delete_projects' ); } else { $role->remove_cap( 'vetra_delete_projects' ); }
	}
	$admin = get_role( 'administrator' );
	if ( $admin ) { foreach ( array( 'vetra_create_projects','vetra_submit_projects','vetra_edit_own_projects','vetra_edit_all_projects','vetra_delete_projects','vetra_manage_projects' ) as $cap ) { $admin->add_cap( $cap ); } }
}
add_action( 'init', 'vetra_access_sync_project_caps', 20 );

function vetra_access_admin_menu() {
	add_users_page( 'دسترسی و نقش‌های وترا', 'دسترسی وترا', 'manage_options', 'vetra-access', 'vetra_access_page' );
}
add_action( 'admin_menu', 'vetra_access_admin_menu' );

function vetra_access_page() {
	if ( ! current_user_can( 'manage_options' ) ) { return; }
	$roles = vetra_access_role_choices();
	$create = vetra_access_selected_roles( 'vetra_project_create_roles', array( 'vetra_project_editor','vetra_project_manager' ) );
	$edit = vetra_access_selected_roles( 'vetra_project_edit_roles', array( 'vetra_project_editor','vetra_project_manager' ) );
	$delete = vetra_access_selected_roles( 'vetra_project_delete_roles', array( 'vetra_project_manager' ) );
	?>
	<div class="wrap vetra-admin-wrap" dir="rtl">
	<h1>دسترسی و نقش‌های وترا</h1>
	<p>مجوزهای ثبت، ویرایش و حذف پروژه مستقل و جداگانه تنظیم می‌شوند. امنیت عملیات در سمت سرور نیز بررسی می‌شود.</p>
	<form method="post"><?php wp_nonce_field( 'vetra_access_save', 'vetra_access_nonce' ); ?>
	<table class="widefat striped" style="max-width:1000px"><thead><tr><th>نقش</th><th>ایجاد پروژه</th><th>ویرایش پروژه‌های خود</th><th>حذف پروژه</th></tr></thead><tbody>
	<?php foreach ( $roles as $slug => $name ) : ?><tr><td><strong><?php echo esc_html( $name ); ?></strong><code><?php echo esc_html( $slug ); ?></code></td>
	<td><input type="checkbox" name="create_roles[]" value="<?php echo esc_attr( $slug ); ?>" <?php checked( in_array( $slug, $create, true ) ); ?>></td>
	<td><input type="checkbox" name="edit_roles[]" value="<?php echo esc_attr( $slug ); ?>" <?php checked( in_array( $slug, $edit, true ) ); ?>></td>
	<td><input type="checkbox" name="delete_roles[]" value="<?php echo esc_attr( $slug ); ?>" <?php checked( in_array( $slug, $delete, true ) ); ?>></td></tr><?php endforeach; ?>
	</tbody></table>
	<p><button class="button button-primary">ذخیره دسترسی‌ها</button></p></form>
	<hr><h2>نقش سفارشی</h2>
	<form method="post"><?php wp_nonce_field( 'vetra_role_create', 'vetra_role_nonce' ); ?><input type="hidden" name="vetra_role_action" value="create">
	<p><label>عنوان نقش <input required class="regular-text" name="role_name"></label>
	<label>شناسه نقش <input required class="regular-text" pattern="[a-z0-9_-]+" name="role_slug"></label></p>
	<p><button class="button">ایجاد نقش</button></p></form>
	<p><strong>نکته:</strong> حذف نقش از رابط کاربری عمداً به حذف کاربران یا داده‌ها منجر نمی‌شود؛ نقش فقط پس از انتقال کاربران آن قابل حذف است.</p>
	</div>
	<?php
}
function vetra_access_admin_actions() {
	if ( ! is_admin() || ! current_user_can( 'manage_options' ) ) { return; }
	if ( isset( $_POST['vetra_access_nonce'] ) && wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['vetra_access_nonce'] ) ), 'vetra_access_save' ) ) {
		update_option( 'vetra_project_create_roles', array_map( 'sanitize_key', (array) ( $_POST['create_roles'] ?? array() ) ), false );
		update_option( 'vetra_project_edit_roles', array_map( 'sanitize_key', (array) ( $_POST['edit_roles'] ?? array() ) ), false );
		update_option( 'vetra_project_delete_roles', array_map( 'sanitize_key', (array) ( $_POST['delete_roles'] ?? array() ) ), false );
		vetra_access_sync_project_caps();
		wp_safe_redirect( add_query_arg( 'saved', 1, admin_url( 'users.php?page=vetra-access' ) ) ); exit;
	}
	if ( isset( $_POST['vetra_role_nonce'] ) && wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['vetra_role_nonce'] ) ), 'vetra_role_create' ) && 'create' === sanitize_key( $_POST['vetra_role_action'] ?? '' ) ) {
		$slug = sanitize_key( wp_unslash( $_POST['role_slug'] ?? '' ) );
		$name = sanitize_text_field( wp_unslash( $_POST['role_name'] ?? '' ) );
		if ( $slug && $name && ! get_role( $slug ) && 0 !== strpos( $slug, 'administrator' ) ) { add_role( $slug, $name, array( 'read' => true ) ); }
		wp_safe_redirect( admin_url( 'users.php?page=vetra-access' ) ); exit;
	}
}
add_action( 'admin_init', 'vetra_access_admin_actions', 5 );

/**
 * Keep ordinary users out of wp-admin. REST, AJAX and admin-post remain available
 * because the front-end project UI uses admin-post and the REST API.
 */
function vetra_block_non_admin_dashboard() {
	if ( ! is_admin() || current_user_can( 'manage_options' ) || wp_doing_ajax() ) { return; }
	$script = isset( $_SERVER['PHP_SELF'] ) ? wp_basename( sanitize_text_field( wp_unslash( $_SERVER['PHP_SELF'] ) ) ) : '';
	if ( in_array( $script, array( 'admin-post.php', 'async-upload.php' ), true ) ) { return; }
	wp_safe_redirect( home_url( '/' ) ); exit;
}
add_action( 'admin_init', 'vetra_block_non_admin_dashboard', 1 );

/**
 * Front-end project portal: [vetra_project_portal].
 */
function vetra_project_portal_shortcode() {
	if ( ! is_user_logged_in() ) { return '<div class="vetra-content-card" role="alert">برای ورود به پنل پروژه ابتدا وارد حساب کاربری شوید.</div>'; }
	$can_create = vetra_project_can_create();
	if ( ! $can_create ) { return '<div class="vetra-content-card" role="alert">حساب شما دسترسی مدیریت پروژه ندارد.</div>'; }
	$mine = vetra_project_query( array( 'created_by' => get_current_user_id(), 'number' => 50 ) );
	ob_start(); ?>
	<div class="vetra-project-portal vetra-container">
		<div class="vetra-content-card"><h2>پنل پروژه‌های من</h2><p>از این بخش می‌توانید پروژه جدید ثبت کنید یا پروژه‌های خود را ویرایش کنید.</p>
		<a class="vetra-button vetra-button--primary" href="#vetra-new-project">ثبت پروژه جدید</a></div>
		<div class="vetra-content-card"><h3>پروژه‌های من</h3>
		<?php if ( $mine ) : ?><div class="vetra-project-portal__list"><?php foreach ( $mine as $project ) : ?>
			<div class="vetra-project-portal__item"><strong><?php echo esc_html( $project->project_name ); ?></strong><span>#<?php echo esc_html( $project->id ); ?></span><a href="<?php echo esc_url( add_query_arg( 'id', $project->id, '#vetra-edit-project' ) ); ?>">ویرایش</a></div>
		<?php endforeach; ?></div><?php else : ?><p>هنوز پروژه‌ای ثبت نکرده‌اید.</p><?php endif; ?></div>
		<div id="vetra-new-project"><h3>ثبت / ویرایش پروژه</h3><?php echo do_shortcode( '[vetra_project_form]' ); ?></div>
	</div>
	<?php return ob_get_clean();
}
add_shortcode( 'vetra_project_portal', 'vetra_project_portal_shortcode' );

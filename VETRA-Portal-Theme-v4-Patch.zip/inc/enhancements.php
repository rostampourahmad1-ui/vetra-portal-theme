<?php
/**
 * Vetra Portal enhancements: cookie consent, maintenance mode, layout variants,
 * sample pages, integration status, page restrictions and PWA install prompt.
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }

function vetra_extra_option( $key, $default = '' ) { return get_theme_mod( 'vetra_' . $key, $default ); }

function vetra_enhancement_media_control( $wp_customize, $key, $label, $section, $priority ) {
	$wp_customize->add_setting( 'vetra_'.$key, array( 'default'=>0, 'sanitize_callback'=>'absint', 'transport'=>'refresh' ) );
	$wp_customize->add_control( new WP_Customize_Media_Control( $wp_customize, 'vetra_'.$key, array( 'label'=>$label, 'section'=>$section, 'mime_type'=>'image', 'priority'=>$priority ) ) );
}

function vetra_enhancements_customizer( $wp_customize ) {
	// Centralized visual identity additions.
	$wp_customize->add_section( 'vetra_brand_assets_section', array( 'title'=>'دارایی‌های هویت بصری', 'panel'=>'vetra_corporate_panel', 'priority'=>8 ) );
	vetra_enhancement_media_control( $wp_customize, 'logo_light', 'لوگوی حالت روشن', 'vetra_brand_assets_section', 10 );
	vetra_enhancement_media_control( $wp_customize, 'logo_dark', 'لوگوی حالت تیره', 'vetra_brand_assets_section', 20 );
	vetra_enhancement_media_control( $wp_customize, 'favicon', 'Favicon / آیکون سایت', 'vetra_brand_assets_section', 30 );
	vetra_enhancement_media_control( $wp_customize, 'custom_icon', 'آیکون اختصاصی', 'vetra_brand_assets_section', 40 );

	$wp_customize->add_section( 'vetra_security_section', array( 'title' => 'امنیت، دسترسی و قوانین', 'panel' => 'vetra_corporate_panel', 'priority' => 74 ) );
	$fields = array(
		'cookie_enabled' => array( 'type'=>'checkbox', 'default'=>false, 'label'=>'فعال‌سازی پیام کوکی' ),
		'cookie_text' => array( 'type'=>'textarea', 'default'=>'این سایت برای بهبود تجربه کاربری از کوکی‌های ضروری استفاده می‌کند.', 'label'=>'متن پیام کوکی' ),
		'cookie_position' => array( 'type'=>'select', 'default'=>'bottom', 'label'=>'جایگاه پیام کوکی', 'choices'=>array('bottom'=>'پایین','top'=>'بالا') ),
		'cookie_policy_page' => array( 'type'=>'select', 'default'=>0, 'label'=>'برگه قوانین و مقررات', 'choices'=>array(0=>'بدون پیوند') + wp_list_pluck( get_pages(), 'post_title', 'ID' ) ),
		'projects_public' => array( 'type'=>'checkbox', 'default'=>true, 'label'=>'نمایش عمومی پروژه‌ها در خروجی‌های عمومی' ),
		'contact_form_id' => array( 'type'=>'number', 'default'=>1, 'label'=>'شناسه فرم Gravity Forms تماس' ),
		'maintenance_mode' => array( 'type'=>'checkbox', 'default'=>false, 'label'=>'فعال‌سازی حالت تعمیر' ),
		'maintenance_title' => array( 'type'=>'text', 'default'=>'سایت در حال به‌روزرسانی است', 'label'=>'عنوان حالت تعمیر' ),
		'maintenance_message' => array( 'type'=>'textarea', 'default'=>'لطفاً کمی بعد دوباره مراجعه کنید.', 'label'=>'پیام حالت تعمیر' ),
		'update_mode' => array( 'type'=>'checkbox', 'default'=>false, 'label'=>'نمایش حالت «سایت در حال به‌روزرسانی»' ),
		'update_message' => array( 'type'=>'textarea', 'default'=>'در حال انجام به‌روزرسانی‌های فنی هستیم.', 'label'=>'پیام به‌روزرسانی' ),
	);
	foreach ( $fields as $key=>$f ) {
		$sanitize = 'checkbox' === $f['type'] ? 'vetra_sanitize_checkbox' : ( 'number' === $f['type'] ? 'absint' : ( 'select' === $f['type'] ? 'absint' : ( 'textarea' === $f['type'] ? 'sanitize_textarea_field' : 'sanitize_text_field' ) ) );
		$wp_customize->add_setting( 'vetra_'.$key, array('default'=>$f['default'],'sanitize_callback'=>$sanitize,'transport'=>'refresh') );
		$control = array('label'=>$f['label'],'section'=>'vetra_security_section','type'=>$f['type'],'priority'=>10);
		if ( isset($f['choices']) ) { $control['choices']=$f['choices']; }
		if ( 'number' === $f['type'] ) { $control['input_attrs']=array('min'=>0,'max'=>1000); }
		$wp_customize->add_control( 'vetra_'.$key, $control );
	}
	$wp_customize->add_section( 'vetra_pwa_install_section', array( 'title'=>'نصب PWA و اعلان نصب', 'panel'=>'vetra_corporate_panel', 'priority'=>76 ) );
	$pwa = array(
		'pwa_install_prompt_enabled'=>array('type'=>'checkbox','default'=>true,'label'=>'نمایش پیشنهاد نصب'),
		'pwa_install_prompt_text'=>array('type'=>'text','default'=>'نسخه اپ وترا را روی دستگاه خود نصب کنید.','label'=>'متن پیشنهاد نصب'),
		'pwa_install_button_text'=>array('type'=>'text','default'=>'نصب اپ','label'=>'متن دکمه نصب'),
		'pwa_install_dismiss_text'=>array('type'=>'text','default'=>'بعداً','label'=>'متن بستن'),
		'pwa_install_delay'=>array('type'=>'number','default'=>3000,'label'=>'تأخیر نمایش (میلی‌ثانیه)'),
	);
	foreach($pwa as $key=>$f){$sanitize='checkbox'===$f['type']?'vetra_sanitize_checkbox':('number'===$f['type']?'absint':'sanitize_text_field');$wp_customize->add_setting('vetra_'.$key,array('default'=>$f['default'],'sanitize_callback'=>$sanitize));$wp_customize->add_control('vetra_'.$key,array('label'=>$f['label'],'section'=>'vetra_pwa_install_section','type'=>$f['type']));}
}
add_action( 'customize_register', 'vetra_enhancements_customizer', 40 );

function vetra_register_full_width_template( $templates ) { $templates['templates/full-width.php'] = 'تمام‌عرض وترا'; return $templates; }
add_filter( 'theme_page_templates', 'vetra_register_full_width_template' );

function vetra_layout_variant( $type, $page_id = 0 ) {
	$page_id = $page_id ?: get_queried_object_id();
	$map = get_post_meta( $page_id, '_vetra_'.$type.'_variant', true );
	$variants = get_option( 'vetra_layout_variants', array() );
	return ( $map && isset( $variants[$type][$map] ) ) ? $variants[$type][$map] : '';
}
function vetra_layout_admin_menu() { add_theme_page('هدر و فوتر وترا','هدر و فوتر','manage_options','vetra-layouts','vetra_layout_admin_page'); }
add_action('admin_menu','vetra_layout_admin_menu');
function vetra_layout_admin_page() {
	if(!current_user_can('manage_options')) return;
	$data=get_option('vetra_layout_variants',array('header'=>array(),'footer'=>array()));
	if(isset($_POST['vetra_layout_nonce']) && wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['vetra_layout_nonce'])),'vetra_layout_save')){
		$type=sanitize_key($_POST['layout_type']??'');$id=sanitize_key($_POST['layout_id']??'');$name=sanitize_text_field(wp_unslash($_POST['layout_name']??''));$html=wp_kses_post(wp_unslash($_POST['layout_html']??''));
		if(in_array($type,array('header','footer'),true)&&$id&&$name){$data[$type][$id]=array('name'=>$name,'html'=>$html);update_option('vetra_layout_variants',$data,false);}
		wp_safe_redirect(admin_url('themes.php?page=vetra-layouts'));exit;
	}
	?>
	<div class="wrap vetra-admin-wrap" dir="rtl"><h1>هدر و فوتر وترا</h1><p>می‌توانید چند نسخه HTML امن بسازید. انتخاب نسخه برای هر برگه از بخش تنظیمات همان برگه انجام می‌شود.</p>
	<?php foreach(array('header'=>'هدر','footer'=>'فوتر') as $type=>$label): ?>
	<div class="vetra-admin-card"><h2><?php echo esc_html($label); ?></h2>
	<?php foreach(($data[$type]??array()) as $id=>$v): ?><p><strong><?php echo esc_html($v['name']); ?></strong> <code><?php echo esc_html($id); ?></code></p><?php endforeach; ?>
	<form method="post"><?php wp_nonce_field('vetra_layout_save','vetra_layout_nonce'); ?><input type="hidden" name="layout_type" value="<?php echo esc_attr($type); ?>"><p><input required class="regular-text" name="layout_id" placeholder="شناسه مثل corporate"></p><p><input required class="regular-text" name="layout_name" placeholder="نام نسخه"></p><p><textarea name="layout_html" rows="6" class="large-text" placeholder="HTML امن / شورتکد"><?php echo esc_textarea(''); ?></textarea></p><button class="button button-primary">ذخیره نسخه <?php echo esc_html($label); ?></button></form></div>
	<?php endforeach; ?></div><?php
}
function vetra_layout_meta_box() {
	foreach(array('header'=>'هدر وترا','footer'=>'فوتر وترا') as $type=>$label) add_meta_box('vetra_'.$type.'_variant',$label,'vetra_layout_meta_box_render','page','side','default',array('type'=>$type));
}
add_action('add_meta_boxes','vetra_layout_meta_box');
function vetra_layout_meta_box_render($post,$box){
	$type=$box['args']['type'];$selected=get_post_meta($post->ID,'_vetra_'.$type.'_variant',true);$variants=get_option('vetra_layout_variants',array());
	wp_nonce_field('vetra_layout_meta','vetra_layout_meta_nonce');
	echo '<select name="vetra_'.$type.'_variant" style="width:100%"><option value="">پیش‌فرض قالب</option>';
	foreach(($variants[$type]??array()) as $id=>$v) echo '<option value="'.esc_attr($id).'" '.selected($selected,$id,false).'>'.esc_html($v['name']).'</option>';
	echo '</select>';
}
function vetra_layout_save_meta($post_id){
	if(defined('DOING_AUTOSAVE')&&DOING_AUTOSAVE) return;if(!isset($_POST['vetra_layout_meta_nonce'])||!wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['vetra_layout_meta_nonce'])),'vetra_layout_meta'))return;if(!current_user_can('edit_post',$post_id))return;
	foreach(array('header','footer') as $type){if(isset($_POST['vetra_'.$type.'_variant'])) update_post_meta($post_id,'_vetra_'.$type.'_variant',sanitize_key($_POST['vetra_'.$type.'_variant']));}
}
add_action('save_post_page','vetra_layout_save_meta');

function vetra_page_role_guard() {
	if(!is_page()) return;$roles=(array)get_post_meta(get_queried_object_id(),'_vetra_allowed_roles',true);if(!$roles) return;
	if(!is_user_logged_in()){auth_redirect();exit;}
	$user=wp_get_current_user();$ok=false;foreach($user->roles as $role){if(in_array($role,$roles,true)){$ok=true;break;}}
	if(!$ok){status_header(403);wp_die('دسترسی شما به این برگه مجاز نیست.','وترا',array('response'=>403));}
}
add_action('template_redirect','vetra_page_role_guard',2);

function vetra_page_roles_meta_box(){add_meta_box('vetra_page_roles','محدودیت نقش کاربری','vetra_page_roles_meta_box_render','page','side','default');}
add_action('add_meta_boxes','vetra_page_roles_meta_box');
function vetra_page_roles_meta_box_render($post){$selected=(array)get_post_meta($post->ID,'_vetra_allowed_roles',true);wp_nonce_field('vetra_page_roles','vetra_page_roles_nonce');echo '<p>اگر نقشی انتخاب نشود، برگه عمومی است.</p>';foreach(wp_roles()->roles as $slug=>$r)echo '<label style="display:block"><input type="checkbox" name="vetra_allowed_roles[]" value="'.esc_attr($slug).'" '.checked(in_array($slug,$selected,true),true,false).'> '.esc_html(translate_user_role($r['name'])).'</label>';}
function vetra_page_roles_save($post_id){if(defined('DOING_AUTOSAVE')&&DOING_AUTOSAVE)return;if(!isset($_POST['vetra_page_roles_nonce'])||!wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['vetra_page_roles_nonce'])),'vetra_page_roles'))return;if(!current_user_can('edit_post',$post_id))return;update_post_meta($post_id,'_vetra_allowed_roles',array_map('sanitize_key',(array)($_POST['vetra_allowed_roles']??array())));}
add_action('save_post_page','vetra_page_roles_save');

function vetra_cookie_notice() {
	if(!vetra_extra_option('cookie_enabled',false)||isset($_COOKIE['vetra_cookie_ok']))return;
	$policy=absint(vetra_extra_option('cookie_policy_page',0));$pos=vetra_extra_option('cookie_position','bottom');
	echo '<aside class="vetra-cookie-notice vetra-cookie-notice--'.esc_attr($pos).'" role="dialog" aria-label="پیام کوکی"><p>'.esc_html(vetra_extra_option('cookie_text','این سایت از کوکی‌های ضروری استفاده می‌کند.')).'</p>';
	if($policy) echo '<a href="'.esc_url(get_permalink($policy)).'">قوانین و مقررات</a>';
	echo '<button type="button" class="js-vetra-cookie-ok">متوجه شدم</button></aside>';
}
add_action('wp_footer','vetra_cookie_notice',20);

function vetra_maintenance_guard(){
	if(is_admin()||wp_doing_ajax()||current_user_can('manage_options'))return;
	$enabled=vetra_extra_option('maintenance_mode',false)||vetra_extra_option('update_mode',false);if(!$enabled)return;
	status_header(503);nocache_headers();
	$title=vetra_extra_option('maintenance_title','سایت در حال به‌روزرسانی است');$msg=vetra_extra_option('maintenance_message','لطفاً کمی بعد دوباره مراجعه کنید.');
	wp_die('<div dir="rtl" style="font-family:Tahoma;text-align:center;padding:15vh 20px"><h1>'.esc_html($title).'</h1><p>'.esc_html($msg).'</p></div>','وترا',array('response'=>503));
}
add_action('template_redirect','vetra_maintenance_guard',1);

function vetra_pwa_prompt_script(){
	if(!vetra_option('pwa_enabled')||!vetra_extra_option('pwa_install_prompt_enabled',true))return;
	wp_enqueue_script('vetra-enhancements',VETRA_PORTAL_URI.'/assets/js/vetra-enhancements.js',array(),VETRA_PORTAL_VERSION,true);
	wp_localize_script('vetra-enhancements','vetraEnhancements',array('delay'=>absint(vetra_extra_option('pwa_install_delay',3000)),'text'=>vetra_extra_option('pwa_install_prompt_text','نسخه اپ وترا را نصب کنید.'),'install'=>vetra_extra_option('pwa_install_button_text','نصب اپ'),'dismiss'=>vetra_extra_option('pwa_install_dismiss_text','بعداً')));
}
add_action('wp_enqueue_scripts','vetra_pwa_prompt_script',30);

function vetra_integration_status() {
	$items=array();
	foreach(array('Elementor'=>'elementor/elementor.php','ElementsKit Lite'=>'elementskit-lite/elementskit-lite.php','Gravity Forms'=>'gravityforms/gravityforms.php') as $name=>$file) $items[$name]=function_exists('is_plugin_active')?is_plugin_active($file):false;
	return $items;
}
function vetra_integration_admin_menu(){add_theme_page('یکپارچه‌سازی‌های وترا','یکپارچه‌سازی‌ها','manage_options','vetra-integrations','vetra_integration_page');}
add_action('admin_menu','vetra_integration_admin_menu');
function vetra_integration_page(){if(!current_user_can('manage_options'))return;$items=vetra_integration_status();echo '<div class="wrap vetra-admin-wrap" dir="rtl"><h1>یکپارچه‌سازی‌های وترا</h1><table class="widefat striped" style="max-width:900px"><tr><th>سرویس</th><th>وضعیت</th></tr>';foreach($items as $name=>$active)echo '<tr><td>'.esc_html($name).'</td><td>'.($active?'<strong style="color:#087f23">فعال</strong>':'غیرفعال / نصب نیست').'</td></tr>';echo '</table><p>کلیدهای API و اتصال‌های هوش مصنوعی باید توسط افزونه یا سرویس امن سمت سرور مدیریت شوند؛ قالب هیچ کلید محرمانه‌ای را در HTML عمومی یا GitHub ذخیره نمی‌کند.</p></div>';}

function vetra_demo_page_definitions() {
	return array(
		'home' => array('title'=>'نمونه صفحه اصلی وترا','content'=>'[vetra_project_list number="6"]'),
		'about' => array('title'=>'نمونه درباره ما وترا','content'=>'<h1>درباره وترا</h1><p>این برگه نمونه برای ویرایش با Elementor آماده شده است.</p>'),
		'services' => array('title'=>'نمونه خدمات وترا','content'=>'<h1>خدمات</h1><p>طراحی، مهندسی، ساخت و توسعه.</p>'),
		'contact' => array('title'=>'نمونه تماس با وترا','content'=>'[vetra_project_portal]'),
	);
}
function vetra_install_demo_pages() {
	$ids=get_option('vetra_demo_page_ids',array());
	foreach(vetra_demo_page_definitions() as $key=>$def){
		if(!empty($ids[$key])&&get_post($ids[$key]))continue;
		$existing=get_page_by_title($def['title']);
		$post=$existing?:get_page_by_path(sanitize_title($def['title']));
		if($post){$ids[$key]=$post->ID;continue;}
		$id=wp_insert_post(array('post_title'=>$def['title'],'post_content'=>$def['content'],'post_status'=>'draft','post_type'=>'page'),true);
		if(!is_wp_error($id)){$ids[$key]=$id;update_post_meta($id,'_vetra_demo_page_key',$key);}
	}
	update_option('vetra_demo_page_ids',$ids,false);
}
add_action('after_switch_theme','vetra_install_demo_pages',30);
function vetra_demo_admin_menu(){add_theme_page('نمونه‌برگه‌های وترا','نمونه‌برگه‌ها','manage_options','vetra-demo-pages','vetra_demo_admin_page');}
add_action('admin_menu','vetra_demo_admin_menu');
function vetra_demo_admin_page(){
	if(!current_user_can('manage_options'))return;
	$ids=get_option('vetra_demo_page_ids',array());
	if(isset($_POST['vetra_demo_nonce'])&&wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['vetra_demo_nonce'])),'vetra_demo')){
		$action=sanitize_key($_POST['demo_action']??'');
		if('rebuild'===$action)vetra_install_demo_pages();
		if('delete'===$action){foreach($ids as $id)wp_delete_post(absint($id),true);delete_option('vetra_demo_page_ids');}
		wp_safe_redirect(admin_url('themes.php?page=vetra-demo-pages'));exit;
	}
	echo '<div class="wrap vetra-admin-wrap" dir="rtl"><h1>نمونه‌برگه‌های وترا</h1><p>نمونه‌ها به‌صورت پیش‌نویس ساخته می‌شوند تا بدون انتشار ناخواسته بتوانید آن‌ها را با Elementor ویرایش کنید.</p><table class="widefat striped" style="max-width:900px"><tr><th>برگه</th><th>عملیات</th></tr>';
	foreach(vetra_demo_page_definitions() as $key=>$def){$id=$ids[$key]??0;echo '<tr><td>'.esc_html($def['title']).'</td><td>'.($id?'<a class="button" href="'.esc_url(get_edit_post_link($id)).'">ویرایش</a>':'ایجاد نشده').'</td></tr>';}
	echo '</table><form method="post" style="margin-top:15px">';wp_nonce_field('vetra_demo','vetra_demo_nonce');echo '<button class="button button-primary" name="demo_action" value="rebuild">ساخت/بازسازی نمونه‌ها</button> <button class="button" name="demo_action" value="delete">حذف کنترل‌شده نمونه‌ها</button></form></div>';
}

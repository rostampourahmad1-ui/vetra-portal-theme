# Vetra Portal 4.0 — Changelog

## Added
- Controlled project REST API and stable field identifiers.
- Separate create/edit/delete capabilities and configurable role mapping.
- Front-end project portal and dashboard restriction for non-admin users.
- Full-width Elementor-compatible page template.
- Draft demo pages with controlled rebuild/delete.
- Role-based page restrictions with server-side enforcement.
- Header/footer variants and centralized visual assets.
- Cookie notice, maintenance/update mode, PWA install prompt and integration status.

## Changed
- Project approval workflow removed from application behavior.
- Contact Gravity Forms ID is configurable.
- Corporate JavaScript now handles cookie acknowledgement.

## Compatibility
- Existing project records remain readable. The old `status` column is retained only as a migration-safe legacy column and is ignored by application logic.

<?php
/**
 * Corporate site footer.
 * @package VetraPortal
 */
?>
</main>
<?php $custom_footer=vetra_layout_variant('footer'); if($custom_footer) echo '<div class="vetra-layout-variant vetra-layout-variant--footer">'.do_shortcode($custom_footer).'</div>'; ?>
<?php if(vetra_option('footer_enabled',true)): ?>
<footer id="contact" class="vetra-footer"><div class="vetra-container"><div class="vetra-footer__top">
<div class="vetra-footer__brand"><a class="vetra-brand" href="<?php echo esc_url(home_url('/')); ?>"><span class="vetra-brand__mark"><img class="vetra-logo-light" src="<?php echo esc_url(vetra_image_url('logo_light')?:vetra_brand_logo_url()); ?>" alt="" /><img class="vetra-logo-dark" src="<?php echo esc_url(vetra_image_url('logo_dark')?:vetra_brand_logo_url()); ?>" alt="" /></span><span class="vetra-brand__copy"><strong><?php echo esc_html(vetra_option('brand_title')); ?></strong><small><?php echo esc_html(vetra_option('brand_subtitle')); ?></small></span></a><p><?php echo esc_html(vetra_option('footer_text')); ?></p></div>
<?php if(vetra_option('footer_contact_enabled',true)): ?><div class="vetra-footer__contact"><span>ارتباط با وترا</span><a href="tel:<?php echo esc_attr(preg_replace('/[^0-9+]/','',vetra_option('contact_phone'))); ?>"><?php echo esc_html(vetra_option('contact_phone')); ?></a><a href="mailto:<?php echo esc_attr(vetra_option('contact_email')); ?>"><?php echo esc_html(vetra_option('contact_email')); ?></a></div><?php endif; ?>
<div class="vetra-footer__address"><span>دفتر مرکزی</span><p><?php echo esc_html(vetra_option('contact_address')); ?></p></div></div>
<?php if(vetra_option('footer_bottom_enabled',true)): ?><div class="vetra-footer__bottom"><span>© <?php echo esc_html(gmdate('Y')); ?> گروه ساختمانی و مهندسی وترا</span><span><?php echo esc_html(vetra_option('footer_text')); ?></span></div><?php endif; ?>
</div></footer><?php endif; ?>
<?php wp_footer(); ?></div></body></html>

(function(){
'use strict';
var deferred=null;
function show(){
 if(!window.vetraEnhancements||document.querySelector('.vetra-pwa-install'))return;
 var box=document.createElement('aside');box.className='vetra-pwa-install';box.setAttribute('role','dialog');box.setAttribute('aria-label','نصب اپ');
 box.innerHTML='<p>'+vetraEnhancements.text+'</p><button class="install">'+vetraEnhancements.install+'</button><button class="dismiss">'+vetraEnhancements.dismiss+'</button>';
 document.body.appendChild(box);
 box.querySelector('.dismiss').addEventListener('click',function(){box.remove();localStorage.setItem('vetra-pwa-dismissed','1');});
 box.querySelector('.install').addEventListener('click',function(){if(deferred){deferred.prompt();deferred.userChoice.finally(function(){deferred=null;box.remove();});}});
}
window.addEventListener('beforeinstallprompt',function(e){e.preventDefault();deferred=e;if(!localStorage.getItem('vetra-pwa-dismissed'))setTimeout(show,Number(vetraEnhancements.delay)||3000);});
})();

<?php
/**
 * Corporate site header.
 * @package VetraPortal
 */
$theme_mode=vetra_option('color_mode','system');
$light_logo=vetra_image_url('logo_light') ?: vetra_brand_logo_url();
$dark_logo=vetra_image_url('logo_dark') ?: vetra_brand_logo_url();
$icon=vetra_image_url('favicon') ?: VETRA_PORTAL_URI.'/assets/images/favicon.png';
?><!doctype html>
<html <?php language_attributes(); ?> dir="rtl" data-theme="<?php echo esc_attr('dark'===$theme_mode?'dark':'light'); ?>" data-theme-mode="<?php echo esc_attr($theme_mode); ?>">
<head>
<meta charset="<?php bloginfo('charset'); ?>"><meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="icon" href="<?php echo esc_url($icon); ?>" type="image/png">
<?php wp_head(); ?>
</head><body <?php body_class(); ?>><?php wp_body_open(); ?><div class="vetra-site-shell">
<?php if(vetra_option('header_enabled',true)): ?>
<header class="vetra-topbar"><div class="vetra-container vetra-topbar__inner">
<a class="vetra-brand" href="<?php echo esc_url(home_url('/')); ?>" aria-label="<?php bloginfo('name'); ?>">
<span class="vetra-brand__mark"><img class="vetra-logo-light" src="<?php echo esc_url($light_logo); ?>" alt="" /><img class="vetra-logo-dark" src="<?php echo esc_url($dark_logo); ?>" alt="" /></span>
<span class="vetra-brand__copy"><strong><?php echo esc_html(vetra_option('brand_title')); ?></strong><small><?php echo esc_html(vetra_option('brand_subtitle')); ?></small></span></a>
<?php if(vetra_option('mobile_menu_enabled',true)||!wp_is_mobile()): ?><nav class="vetra-site-nav" aria-label="ناوبری اصلی">
<a href="<?php echo esc_url(home_url('/')); ?>">خانه</a><a href="<?php echo esc_url(home_url('/#about')); ?>">درباره وترا</a><a href="<?php echo esc_url(home_url('/#services')); ?>">خدمات</a><a href="<?php echo esc_url(home_url('/#projects')); ?>">پروژه‌ها</a><a href="<?php echo esc_url(home_url('/#contact')); ?>">تماس با ما</a>
</nav><?php endif; ?>
<div class="vetra-topbar__actions"><?php if(vetra_option('show_theme_switch',true)): ?><button class="vetra-mode-toggle js-vetra-mode-toggle" type="button" aria-label="تغییر حالت رنگی"><span><?php echo vetra_inline_icon('sun'); ?></span></button><?php endif; ?><?php if(vetra_option('header_cta_enabled',true)): ?><a class="vetra-header-cta" href="<?php echo esc_url(vetra_option('header_cta_url')); ?>"><?php echo esc_html(vetra_option('header_cta_text')); ?><span><?php echo vetra_inline_icon('arrow-up'); ?></span></a><?php endif; ?><?php if(vetra_option('mobile_menu_enabled',true)): ?><button class="vetra-mobile-toggle js-vetra-mobile-toggle" type="button" aria-label="منوی سایت" aria-expanded="false"><?php echo vetra_inline_icon('menu'); ?></button><?php endif; ?></div>
</div></header>
<?php endif; ?>
<?php $custom_header=vetra_layout_variant('header'); if($custom_header) echo '<div class="vetra-layout-variant vetra-layout-variant--header">'.do_shortcode($custom_header).'</div>'; ?>
<?php do_action('vetra_after_header'); ?><main id="primary" class="vetra-main">

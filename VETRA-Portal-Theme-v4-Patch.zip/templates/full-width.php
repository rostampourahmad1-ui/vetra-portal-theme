<?php
/**
 * Template Name: تمام‌عرض وترا
 * Template Post Type: page
 */
get_header();
?>
<div class="vetra-full-width-page">
	<?php while ( have_posts() ) : the_post(); ?>
		<article <?php post_class( 'vetra-page-content' ); ?>>
			<?php the_content(); ?>
		</article>
	<?php endwhile; ?>
</div>
<?php get_footer(); ?>
